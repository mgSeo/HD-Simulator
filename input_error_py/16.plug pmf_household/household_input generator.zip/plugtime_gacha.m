clc, clear, close all

% number of samples to gacha
n = 50000;
data_out = zeros(n,3);
soc_pmf = readmatrix('pmf_ini_SOC.csv');

%% departure time pdf
mu = 9.97;
sigma = 2.2;

r = normrnd(mu,sigma,[n,1]);
R = round(r); % in-time

idx = find(R<1);
if isempty(idx) == 0
    R(idx) = R(idx) + 24;
end
data_out(:,2) = R;

%% arrival time pdf
mu = 17.01;
sigma = 3.2;

r = normrnd(mu,sigma,[n,1]);
R = round(r); % in-time

idx = find(R>24);
if isempty(idx) == 0
    R(idx) = R(idx) - 24;
end
data_out(:,1) = R;

%% sampling: initial soc
for t = 1:n
    v = soc_pmf(:,1);
    p = soc_pmf(:,data_out(t,1)+1);
    c = cumsum([0,p(:).']);
    c = c/c(end); % make sur the cumulative is 1
    [~,i] = histc(rand(1),c);
    data_out(t,3) = v(i);
end

%% data out
writematrix(data_out,'out_plug_time.csv')